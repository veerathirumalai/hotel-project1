<?php
session_start();
include("db_connect.php");

if ($_POST['otp'] != $_SESSION['otp']) {
    die("❌ Invalid OTP");
}

$username = $_SESSION['username'];
$password = $_SESSION['password'];
$mobile   = $_SESSION['mobile'];

$sql = "INSERT INTO users (username, password, role, mobile)
        VALUES ('$username', '$password', 'staff', '$mobile')";

if (!mysqli_query($conn, $sql)) {
    die("DB Error: ".mysqli_error($conn));
}

session_destroy();
?>

<!DOCTYPE html>
<html>
<head>
<title>Signup Successful</title>
<style>
.box{
    width:400px;
    margin:100px auto;
    background:white;
    padding:25px;
    border-radius:10px;
    text-align:center;
    box-shadow:0 10px 20px rgba(0,0,0,0.15);
}
</style>
</head>
<body style="background:#eef2f7;font-family:Arial;">

<div class="box">
    <h2 style="color:green;">✅ Signup Successful</h2>
    <p>You can now login using your username and password.</p>
    <a href="login.php">
        <button>Login Now</button>
    </a>
</div>

</body>
</html>
