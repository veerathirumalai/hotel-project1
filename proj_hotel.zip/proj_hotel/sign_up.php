<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>Staff Signup</title>

<style>
body{
    background:#eef2f7;
    font-family:Arial;
}
.signup-box{
    width:380px;
    margin:80px auto;
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
}
.signup-box h2{
    text-align:center;
    margin-bottom:20px;
}
.signup-box input{
    width:100%;
    padding:10px;
    margin:8px 0;
    border:1px solid #ccc;
    border-radius:5px;
}
.signup-box button{
    width:100%;
    padding:10px;
    background:#1b1f3b;
    color:white;
    border:none;
    border-radius:5px;
    cursor:pointer;
}
.signup-box button:hover{
    background:#4a4e69;
}
.signup-box p{
    text-align:center;
    margin-top:15px;
}
</style>

</head>
<body>

<div class="signup-box">
<h2>Staff Signup</h2>

<form method="post" action="otp_verify.php">
    Username:<br>
    <input type="text" name="username" required>

    Password:<br>
    <input type="password" name="password" required>

    Mobile Number:<br>
    <input type="text" name="mobile" pattern="[0-9]{10}" required>

    <button type="submit">Send OTP</button>
</form>

<p>Already registered? <a href="login.php">Login</a></p>
</div>

</body>
</html>
