<?php
session_start();
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request");
}

if (empty($_POST['room_no']) || empty($_POST['checkout_date']) || empty($_POST['checkout_time'])) {
    die("Missing checkout data");
}

$room_no       = (int)$_POST['room_no'];
$checkout_date = $_POST['checkout_date'];
$checkout_time = $_POST['checkout_time'];
$discount      = (float)($_POST['discount_amount'] ?? 0);
$gst_percent   = 5;

/* 🔹 Fetch last active check-in */
$q = mysqli_query($conn, "
    SELECT c.*, r.price
    FROM checkins c
    JOIN rooms r ON r.room_no = c.room_no
    WHERE c.room_no = '$room_no'
    ORDER BY c.id DESC
    LIMIT 1
");

$c = mysqli_fetch_assoc($q);
if (!$c) die("No active booking");

/* 🔹 Calculate stay days */
$in  = strtotime($c['arrival_date'].' '.$c['arrival_time']);
$out = strtotime($checkout_date.' '.$checkout_time);

$days = ceil(($out - $in) / 86400);
if ($days < 1) $days = 1;

/* 🔹 Billing calculations */
$price   = (float)$c['price'];
$advance = (float)$c['advance_amount']; // ✅ CORRECT DB FIELD

$subtotal    = $price * $days;
$gst_amount  = ($subtotal * $gst_percent) / 100;
$grand_total = $subtotal + $gst_amount;

$payable = $grand_total - ($advance + $discount);
if ($payable < 0) $payable = 0;

/* 🔹 Update checkins */
mysqli_query($conn, "
    UPDATE checkins SET
        checkout_date   = '$checkout_date',
        checkout_time   = '$checkout_time',
        total_days      = '$days',
        total_amount    = '$subtotal',
        gst_amount      = '$gst_amount',
        discount_amount = '$discount',
        payable_amount  = '$payable'
    WHERE id = '{$c['id']}'
");

/* 🔹 Mark room available */
mysqli_query($conn, "
    UPDATE rooms SET status='available' WHERE room_no='$room_no'
");

/* 🔹 Store bill for printing */
$_SESSION['bill'] = [
    'room'        => $room_no,
    'name'        => $c['customer_name'],
    'mobile'      => $c['mobile'],

    'checkin'     => $c['arrival_date'],
    'checkout'    => $checkout_date,
    'time'        => $checkout_time,

    'days'        => $days,
    'price'       => $price,

    'subtotal'    => $subtotal,
    'gst_percent' => $gst_percent,
    'gst_amount'  => $gst_amount,

    'advance'     => $advance,
    'discount'    => $discount,
    'payable'     => $payable
];

header("Location: printbill.php");
exit();
