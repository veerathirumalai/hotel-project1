<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['room']) || empty($_GET['room'])) {
    die("Room not selected");
}

$roomNo = (int) $_GET['room'];

// FETCH ROOM
$q = mysqli_query($conn,"
    SELECT room_type, price, status
    FROM rooms
    WHERE room_no='$roomNo'
    LIMIT 1
");

$room = mysqli_fetch_assoc($q);

if (!$room) {
    die("Invalid Room");
}

if ($room['status'] === 'booked') {
    echo "<script>
        alert('Room already booked!');
        window.location='dashboard.php';
    </script>";
    exit();
}

$roomType = $room['room_type'];
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Room Check-In</title>

<style>
body {
    background:#f4f6f9;
    font-family: Arial;
}
.form-wrapper {
    width: 900px;
    margin: 30px auto;
    background: #fff;
    padding: 25px;
    border-radius: 8px;
}
.section {
    border:1px solid #ddd;
    padding:15px;
    margin-bottom:20px;
}
.grid {
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:15px;
}
.field label {
    font-weight:bold;
    font-size:13px;
}
.field input, .field select {
    width:100%;
    padding:8px;
}
.actions {
    text-align:center;
}
.actions button {
    padding:10px 35px;
    background:#1b1f3b;
    color:#fff;
    border:none;
    cursor:pointer;
}
</style>

<script>
function toggleOtherId(){
    const t = document.getElementById("id_type").value;
    const o = document.getElementById("other_id");
    o.style.display = (t === "Others") ? "block" : "none";
}
</script>

</head>
<body>

<div class="form-wrapper">

<h2>Check-In : Room <?= $roomNo ?> (<?= htmlspecialchars($roomType) ?>)</h2>

<form action="checkin.php" method="POST">

<input type="hidden" name="room_no" value="<?= $roomNo ?>">
<input type="hidden" name="checkin_by" value="<?= $_SESSION['username'] ?>">


<!-- ================= CUSTOMER DETAILS ================= -->
<div class="section">
<h3>Customer Details</h3>
<div class="grid">
    <div class="field">
        <label>Name</label>
        <input type="text" name="customer_name" required>
    </div>

    <div class="field">
        <label>Mobile</label>
        <input type="text" name="mobile" maxlength="10" required>
    </div>

    <div class="field">
        <label>Age</label>
        <input type="number" name="age">
    </div>

    <div class="field">
        <label>Father Name</label>
        <input type="text" name="father_name">
    </div>
</div>
</div>

<!-- ================= ADDRESS DETAILS ================= -->
<div class="section">
<h3>Address Details</h3>
<div class="grid">
    <div class="field"><label>Door No</label><input name="door_no"></div>
    <div class="field"><label>Street</label><input name="street"></div>
    <div class="field"><label>Area</label><input name="area"></div>
    <div class="field"><label>City</label><input name="city"></div>
    <div class="field"><label>District</label><input name="district"></div>
    <div class="field"><label>Pincode</label><input name="pincode"></div>
</div>
</div>

<!-- ================= IDENTITY DETAILS ================= -->
<div class="section">
<h3>Identity Proof</h3>
<div class="grid">
    <div class="field">
        <label>ID Type</label>
        <select name="id_type" id="id_type" onchange="toggleOtherId()" required>
            <option value="">Select</option>
            <option>Aadhar</option>
            <option>Voter ID</option>
            <option>Driving License</option>
            <option>Passport</option>
            <option>Others</option>
        </select>
        <input type="text" name="other_id" id="other_id"
               placeholder="Specify Other ID"
               style="display:none;">
    </div>

    <div class="field">
        <label>ID Number</label>
        <input name="id_number" required>
    </div>
</div>
</div>

<!-- ================= STAY DETAILS ================= -->
<div class="section">
<h3>Stay Details</h3>
<div class="grid">
    <div class="field">
        <label>Nationality</label>
        <input name="nationality">
    </div>

    <div class="field">
        <label>No. of Persons</label>
        <input type="number" name="persons">
    </div>

    <div class="field">
        <label>Arrival Date</label>
        <input type="date" name="arrival_date" required>
    </div>

    <div class="field">
        <label>Arrival Time</label>
        <input type="time" name="arrival_time" required>
    </div>

    <div class="field">
        <label>Advance Amount</label>
        <input type="number" name="advance_amount">
    </div>

    <div class="field">
        <label>Remark</label>
        <textarea name="remark"></textarea>
    </div>
</div>
</div>

<!-- ================= ACTIONS ================= -->
<div class="actions">
    <button type="submit">Confirm Check-In & Print</button>
</div>

</form>
</div>

</body>
</html>
