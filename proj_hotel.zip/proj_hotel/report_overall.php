<?php
session_start();
include 'db_connect.php';

$rows = [];

if (isset($_POST['from'])) {
    $from = $_POST['from'];
    $to   = $_POST['to'];

    $q = "SELECT * FROM checkins
          WHERE arrival_date BETWEEN '$from' AND '$to'";
    $rows = mysqli_query($conn, $q);
}
?>

<h2>📊 Overall Report</h2>

<form method="post">
    From: <input type="date" name="from" required>
    To: <input type="date" name="to" required>
    <button type="submit">Generate</button>
</form>

<?php if($rows) { ?>
<table border="1" width="100%">
<tr>
<th>Date</th>
<th>Room</th>
<th>Name</th>
<th>User</th>
<th>Amount</th>
</tr>

<?php while($r = mysqli_fetch_assoc($rows)) { ?>
<tr>
<td><?= $r['arrival_date'] ?></td>
<td><?= $r['room_no'] ?></td>
<td><?= $r['customer_name'] ?></td>
<td><?= $r['checkin_by'] ?></td>
<td><?= $r['advance_amount'] ?></td>
</tr>
<?php } ?>
</table>
<?php } ?>