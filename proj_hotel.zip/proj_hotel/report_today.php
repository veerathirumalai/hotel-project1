<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$today = date('Y-m-d');

/* ---------------- CHECKED IN TODAY ---------------- */
$checkin_q = mysqli_query($conn,"
    SELECT * FROM checkins
    WHERE arrival_date = '$today'
    ORDER BY arrival_time ASC
");

/* ---------------- CHECKED OUT TODAY ---------------- */
$checkout_q = mysqli_query($conn,"
    SELECT * FROM checkins
    WHERE checkout_date = '$today'
    ORDER BY checkout_time ASC
");

/* ---------------- STILL STAYING ---------------- */
/* FIX: rooms use status='booked' (see checkin.php), not 'occupied' */
$stay_q = mysqli_query($conn,"
    SELECT c.*
    FROM checkins c
    JOIN rooms r ON r.room_no = c.room_no
    WHERE r.status = 'booked'
    ORDER BY c.arrival_date ASC
");

?>

<!DOCTYPE html>
<html>
<head>
<title>Daily Report</title>
<style>
body{font-family:Arial;background:#f4f6f9}
.box{width:95%;margin:20px auto;background:#fff;padding:20px;border-radius:8px}
h2{margin-top:40px}
table{width:100%;border-collapse:collapse;margin-top:10px}
th,td{border:1px solid #333;padding:6px;font-size:13px;text-align:center}
th{background:#1b1f3b;color:#fff}
.print-btn{margin-top:15px;padding:8px 14px}
</style>
</head>
<body>

<div class="box">
<h1>📋 Daily Report – <?= date('d-m-Y') ?></h1>

<button onclick="window.print()" class="print-btn">🖨 Print</button>

<!-- CHECK-IN TODAY -->
<h2>🟢 Checked-IN Today</h2>
<table>
<tr>
<th>Room</th><th>Name</th><th>Mobile</th><th>ID</th>
<th>Check-in Time</th><th>Advance</th>
</tr>

<?php while($c=mysqli_fetch_assoc($checkin_q)){ ?>
<tr>
<td><?= $c['room_no'] ?></td>
<td><?= htmlspecialchars($c['customer_name']) ?></td>
<td><?= $c['mobile'] ?></td>
<td><?= $c['id_type']." - ".$c['id_number'] ?></td>
<td><?= date("h:i A",strtotime($c['arrival_time'])) ?></td>
<td>₹<?= $c['advance_amount'] ?></td>
</tr>
<?php } ?>
</table>

<!-- CHECK-OUT TODAY -->
<h2>🔴 Checked-OUT Today</h2>
<table>
<tr>
<th>Room</th><th>Name</th><th>Mobile</th>
<th>Check-out Time</th><th>Payable</th>
</tr>

<?php while($c=mysqli_fetch_assoc($checkout_q)){ ?>
<tr>
<td><?= $c['room_no'] ?></td>
<td><?= htmlspecialchars($c['customer_name']) ?></td>
<td><?= $c['mobile'] ?></td>
<td><?= date("h:i A",strtotime($c['checkout_time'])) ?></td>
<td>₹<?= $c['payable_amount'] ?></td>
</tr>
<?php } ?>
</table>

<!-- STILL STAYING -->
<h2>🟡 Still Staying</h2>
<table>
<tr>
<th>Room</th><th>Name</th><th>Mobile</th>
<th>Check-in Date</th><th>Days</th>
</tr>

<?php while($c=mysqli_fetch_assoc($stay_q)){
    $days = (strtotime($today) - strtotime($c['arrival_date'])) / (60*60*24) + 1;
?>
<tr>
<td><?= $c['room_no'] ?></td>
<td><?= htmlspecialchars($c['customer_name']) ?></td>
<td><?= $c['mobile'] ?></td>
<td><?= date("d-m-Y",strtotime($c['arrival_date'])) ?></td>
<td><?= (int)$days ?></td>
</tr>
<?php } ?>
</table>

</div>
</body>
</html>