<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Invalid request");
}

$room_no = $_POST['room_no'];
$checkin_by = $_SESSION['username'];

mysqli_begin_transaction($conn);

try {

    // Lock room
    $r = mysqli_query($conn,"
        SELECT status FROM rooms
        WHERE room_no='$room_no'
        FOR UPDATE
    ");
    $room = mysqli_fetch_assoc($r);

    if (!$room || $room['status'] === 'booked') {
        throw new Exception("Room already booked");
    }

    // ID TYPE
    $id_type = $_POST['id_type'];
    if ($id_type === 'Others') {
        $id_type = $_POST['other_id'];
    }

    // INSERT CHECKIN
    $sql = "
        INSERT INTO checkins (
            room_no, customer_name, mobile, age, father_name,
            door_no, street, area, city, district, pincode,
            nationality, id_type, id_number, persons,
            arrival_date, arrival_time, advance_amount, remark,
            checkin_by
        ) VALUES (
            '$room_no',
            '{$_POST['customer_name']}',
            '{$_POST['mobile']}',
            '{$_POST['age']}',
            '{$_POST['father_name']}',
            '{$_POST['door_no']}',
            '{$_POST['street']}',
            '{$_POST['area']}',
            '{$_POST['city']}',
            '{$_POST['district']}',
            '{$_POST['pincode']}',
            '{$_POST['nationality']}',
            '$id_type',
            '{$_POST['id_number']}',
            '{$_POST['persons']}',
            '{$_POST['arrival_date']}',
            '{$_POST['arrival_time']}',
            '{$_POST['advance_amount']}',
            '{$_POST['remark']}',
            '$checkin_by'
        )
    ";

    mysqli_query($conn, $sql);
$checkin_id = mysqli_insert_id($conn);

mysqli_query($conn,"
    UPDATE rooms SET status='booked'
    WHERE room_no='$room_no'
");

mysqli_commit($conn);

header("Location: checkin_print.php?id=$checkin_id");
exit();

} catch (Exception $e) {
    mysqli_rollback($conn);
    echo "<script>alert('{$e->getMessage()}');location='dashboard.php';</script>";
}
