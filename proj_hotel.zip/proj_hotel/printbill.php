<?php
session_start();
$b = $_SESSION['bill'] ?? null;
if(!$b) die("No bill");

function dmy($d){
    return date("d-m-Y", strtotime($d));
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Checkout Bill</title>
<style>
body{font-family:Arial}
.bill{
    width:380px;
    margin:30px auto;
    border:1px solid #000;
    padding:20px;
    font-size:14px
}
hr{border:1px dashed #000}
.total{font-size:16px;font-weight:bold}
button,a{
    padding:8px 14px;
    margin-top:10px;
    display:inline-block;
    text-decoration:none
}
</style>
</head>
<body>

<div class="bill">
<h3>HOTEL BILL</h3>
<hr>

<p><b>Room No:</b> <?= $b['room'] ?></p>
<p><b>Name:</b> <?= htmlspecialchars($b['name']) ?></p>
<p><b>Mobile:</b> <?= $b['mobile'] ?></p>

<hr>

<p><b>Check-in:</b> <?= dmy($b['checkin']) ?></p>
<p><b>Check-out:</b> <?= dmy($b['checkout']) ?></p>
<p><b>No of Days:</b> <?= $b['days'] ?></p>
<p><b>Rent / Day:</b> ₹<?= number_format($b['price'],2) ?></p>

<hr>

<p>Sub Total: ₹<?= number_format($b['subtotal'],2) ?></p>
<p>GST (<?= $b['gst_percent'] ?>%): ₹<?= number_format($b['gst_amount'],2) ?></p>
<p>Advance Paid: ₹<?= number_format($b['advance'],2) ?></p>
<p>Discount: ₹<?= number_format($b['discount'],2) ?></p>

<hr>

<p class="total">Payable Amount: ₹<?= number_format($b['payable'],2) ?></p>

<p><b>Checkout Time:</b> <?= date("h:i A", strtotime($b['time'])) ?></p>

<hr>

<button onclick="window.print()">🖨 Print</button>
<a href="dashboard.php">⬅ Dashboard</a>
</div>

</body>
</html>
