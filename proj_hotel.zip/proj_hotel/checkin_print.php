<?php
session_start();
include 'db_connect.php';

if (!isset($_GET['id'])) {
    die("Invalid access");
}

$id = $_GET['id'];

$q = mysqli_query($conn, "
    SELECT c.*, r.price, r.room_type
    FROM checkins c
    JOIN rooms r ON r.room_no = c.room_no
    WHERE c.id = '$id'
");

$data = mysqli_fetch_assoc($q);

if (!$data) {
    die("No data found");
}

$total = $data['price'];
$advance = $data['advance_amount'];
$pending = $total - $advance;
?>
<!DOCTYPE html>
<html>
<head>
    <title>Check-in Bill</title>
    <style>
        body { font-family: Arial; }
        .bill { width: 300px; margin: auto; }
        h2 { text-align: center; }
        hr { border: 1px dashed #000; }
    </style>
</head>
<body>

<div class="bill">
    <h2>HOTEL CHECK-IN BILL</h2>
    <hr>

    <p><b>Room No:</b> <?= $data['room_no'] ?></p>
    <p><b>Name:</b> <?= $data['customer_name'] ?></p>
    <p><b>Mobile:</b> <?= $data['mobile'] ?></p>
    <p><b>Arrival:</b> <?= $data['arrival_date'] ?> <?= $data['arrival_time'] ?></p>

    <hr>

    <p>Total Amount: ₹<?= $total ?></p>
    <p>Advance Paid: ₹<?= $advance ?></p>
    <p><b>Pending Amount: ₹<?= $pending ?></b></p>

    <hr>

    <p>Checked in by: <?= $data['checkin_by'] ?></p>
</div>

<script>
    window.print();
   
    
   
  
</script>
<div style="text-align:center; margin-top:15px;">
    <button onclick="goDashboard()">Back to Dashboard</button>
</div>

<script>
function goDashboard() {
    window.location.href = "dashboard.php";
}
</script>


</body>
</html>
