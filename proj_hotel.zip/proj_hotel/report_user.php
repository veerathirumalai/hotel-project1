<?php
include 'db_connect.php';

$date = $_GET['date'] ?? date('Y-m-d');

/* Fetch checkout records */
$q = mysqli_query($conn,"
    SELECT *
    FROM checkins
    WHERE checkout_date = '$date'
    ORDER BY checkout_time ASC
");

/* Summary variables */
$sum_subtotal = 0;
$sum_gst      = 0;
$sum_advance  = 0;
$sum_discount = 0;
$sum_payable  = 0;
?>

<!DOCTYPE html>
<html>
<head>
<title>GST Report</title>
<style>
body{font-family:Arial}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{border:1px solid #000;padding:6px;text-align:center}
th{background:#f0f0f0}
.summary{margin-top:20px;font-size:15px}
button{padding:6px 12px;margin:10px 0}
</style>
</head>
<body>

<h3>GST & Amount Summary Report</h3>

<form method="get">
    <label>Select Date:</label>
    <input type="date" name="date" value="<?= $date ?>">
    <button type="submit">View</button>
</form>

<table>
<tr>
    <th>Room</th>
    <th>Name</th>
    <th>Check-in</th>
    <th>Check-out</th>
    <th>Days</th>
    <th>Rent</th>
    <th>Subtotal</th>
    <th>GST</th>
    <th>Advance</th>
    <th>Discount</th>
    <th>Payable</th>
</tr>

<?php while($r = mysqli_fetch_assoc($q)): 

    $subtotal = (float)$r['total_amount'];
    $gst      = (float)$r['gst_amount'];
    $advance  = (float)$r['advance_amount'];
    $discount = (float)$r['discount_amount'];
    $payable  = (float)$r['payable_amount'];

    $days = max(1, (int)$r['total_days']);
    $rent = $subtotal / $days;

    $sum_subtotal += $subtotal;
    $sum_gst      += $gst;
    $sum_advance  += $advance;
    $sum_discount += $discount;
    $sum_payable  += $payable;
?>
<tr>
    <td><?= $r['room_no'] ?></td>
    <td><?= $r['customer_name'] ?></td>
    <td><?= date("d-m-Y", strtotime($r['arrival_date'])) ?></td>
    <td><?= date("d-m-Y", strtotime($r['checkout_date'])) ?></td>
    <td><?= $days ?></td>
    <td>₹<?= number_format($rent,2) ?></td>
    <td>₹<?= number_format($subtotal,2) ?></td>
    <td>₹<?= number_format($gst,2) ?></td>
    <td>₹<?= number_format($advance,2) ?></td>
    <td>₹<?= number_format($discount,2) ?></td>
    <td>₹<?= number_format($payable,2) ?></td>
</tr>
<?php endwhile; ?>
