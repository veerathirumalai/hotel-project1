<?php
session_start();

/* =========================================================
   FLASH SUCCESS MESSAGE
========================================================= */

if (isset($_SESSION['flash_success'])) {

    $msg  = $_SESSION['flash_success'];
    $room = $_SESSION['print_room'] ?? '';

    unset(
        $_SESSION['flash_success'],
        $_SESSION['print_room']
    );
?>

<script>

alert(<?= json_encode($msg) ?>);

<?php if ($room): ?>

window.open(
    "printbill.php?room=<?= urlencode($room) ?>",
    "_blank"
);

<?php endif; ?>

</script>

<?php
}


/* =========================================================
   LOGIN CHECK
========================================================= */

if (!isset($_SESSION['username'])) {

    header("Location: login.php");
    exit();

}


/* =========================================================
   DATABASE
========================================================= */

include "db_connect.php";


$username = $_SESSION['username'];

$lastlog = $_SESSION['lastlog'] ?? "First Login";


/* =========================================================
   FETCH ROOMS
========================================================= */

$rooms = mysqli_query(
    $conn,
    "SELECT * FROM rooms ORDER BY room_no"
);

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
      content="width=device-width, initial-scale=1.0">

<title>Grand Palace Hotel - Dashboard</title>


<style>

/* =========================================================
   GLOBAL
========================================================= */

* {

    margin: 0;

    padding: 0;

    box-sizing: border-box;

}

body {

    font-family:
        Arial,
        Helvetica,
        sans-serif;

    background:
        linear-gradient(
            135deg,
            #eef5fb,
            #f7fafc
        );

    color: #10234b;

    min-height: 100vh;

}


/* =========================================================
   SIDEBAR
========================================================= */

.sidebar {

    width: 250px;

    height: 100vh;

    position: fixed;

    left: 0;

    top: 0;

    background:
        linear-gradient(
            180deg,
            #071b35,
            #102c4a,
            #153e52
        );

    color: white;

    padding-top: 20px;

    box-shadow:
        3px 0 20px rgba(0,0,0,0.18);

    overflow-y: auto;

    z-index: 1000;

}


/* scrollbar */

.sidebar::-webkit-scrollbar {

    width: 5px;

}

.sidebar::-webkit-scrollbar-thumb {

    background:
        rgba(255,255,255,0.25);

    border-radius: 10px;

}


/* =========================================================
   SIDEBAR LOGO
========================================================= */

.logo-area {

    display: flex;

    align-items: center;

    gap: 12px;

    padding:
        5px 18px 28px;

}

.logo-icon {

    width: 45px;

    height: 45px;

    border-radius: 12px;

    background:
        linear-gradient(
            135deg,
            #f7c948,
            #ffdf73
        );

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 23px;

    color: #172b4d;

}

.logo-text h2 {

    font-size: 18px;

    color: white;

}

.logo-text p {

    font-size: 10px;

    color: #aebed0;

    margin-top: 3px;

}


/* =========================================================
   MENU TITLE
========================================================= */

.menu-title {

    font-size: 11px;

    font-weight: bold;

    color: #91a6bd;

    letter-spacing: 1px;

    padding:
        0 20px 8px;

}


/* =========================================================
   SIDEBAR LINKS
========================================================= */

.sidebar a,
.dropdown-btn {

    display: flex;

    align-items: center;

    gap: 12px;

    padding:
        13px 20px;

    margin:
        4px 10px;

    border-radius: 9px;

    color: #e7edf5;

    text-decoration: none;

    cursor: pointer;

    transition: 0.25s;

}

.sidebar a:hover,
.dropdown-btn:hover {

    background:
        rgba(255,255,255,0.10);

    transform:
        translateX(2px);

}


/* active */

.dashboard-link {

    background:
        linear-gradient(
            135deg,
            #3478dc,
            #2865bb
        );

    box-shadow:
        0 7px 18px
        rgba(36,103,196,0.3);

}

.dashboard-link:hover {

    background:
        linear-gradient(
            135deg,
            #3478dc,
            #2865bb
        ) !important;

}


/* icons */

.menu-icon {

    width: 25px;

    text-align: center;

    font-size: 18px;

}

.arrow {

    margin-left: auto;

    font-size: 11px;

}


/* =========================================================
   DROPDOWN
========================================================= */

.dropdown-container {

    display: none;

    background:
        rgba(0,0,0,0.10);

    margin:
        0 10px 8px;

    padding:
        4px 8px;

    border-radius: 8px;

}

.dropdown-container a {

    font-size: 12px;

    padding:
        9px 12px;

    margin: 2px 0;

    color: #c5d2e0;

}

.dropdown-container a:hover {

    background:
        rgba(255,255,255,0.07);

    transform: none;

    color: white;

}


/* =========================================================
   SIDEBAR LINE
========================================================= */

.sidebar-line {

    height: 1px;

    background:
        rgba(255,255,255,0.12);

    margin:
        15px 15px;

}


/* =========================================================
   MAIN
========================================================= */

.main {

    margin-left: 250px;

    min-height: 100vh;

}


/* =========================================================
   HEADER
========================================================= */

.top-header {

    height: 82px;

    background:
        rgba(255,255,255,0.94);

    border-bottom:
        1px solid #e4eaf0;

    display: flex;

    align-items: center;

    justify-content: space-between;

    padding:
        0 32px;

    position: sticky;

    top: 0;

    z-index: 500;

    backdrop-filter:
        blur(10px);

}


/* =========================================================
   HOTEL TITLE + TAMIL TYPING
========================================================= */

.hotel-title {

    display: flex;

    align-items: center;

    gap: 14px;

}


/* local crown */

.crown-image {

    width: 55px;

    height: 55px;

    display: flex;

    align-items: center;

    justify-content: center;

    flex-shrink: 0;

}


/* crown rotation */

.crown-image img {

    width: 48px;

    height: 48px;

    object-fit: contain;

    animation:
        crownRotate 10s linear infinite;

    filter:
        drop-shadow(
            0 4px 5px
            rgba(0,0,0,0.15)
        );

}


/* slow rotation */

@keyframes crownRotate {

    from {

        transform:
            rotate(0deg);

    }

    to {

        transform:
            rotate(360deg);

    }

}


/* hotel name */

.hotel-name {

    min-width: 300px;

}


.hotel-name h1 {

    font-family:
        "Nirmala UI",
        "Latha",
        Arial,
        sans-serif;

    font-size: 23px;

    font-weight: 700;

    color: #142c55;

    margin: 0;

    min-height: 32px;

    white-space: nowrap;

}


/* cursor */

#hotelTyping::after {

    content: "|";

    color: #2872ce;

    margin-left: 3px;

    animation:
        cursorBlink 0.7s infinite;

}


@keyframes cursorBlink {

    0%,
    50% {

        opacity: 1;

    }

    51%,
    100% {

        opacity: 0;

    }

}


.hotel-name p {

    font-size: 11px;

    color: #7d8ca0;

    margin-top: 3px;

}


/* =========================================================
   HEADER RIGHT
========================================================= */

.header-right {

    display: flex;

    align-items: center;

    gap: 22px;

}


.last-login {

    border-right:
        1px solid #dce3eb;

    padding-right: 22px;

    color: #7a8798;

    font-size: 11px;

}


.last-login strong {

    display: block;

    color: #182e53;

    font-size: 12px;

    margin-top: 4px;

}


.user-box {

    display: flex;

    align-items: center;

    gap: 9px;

}


.user-avatar {

    width: 42px;

    height: 42px;

    border-radius: 50%;

    background:
        linear-gradient(
            135deg,
            #3478dc,
            #183f7e
        );

    color: white;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 18px;

}


.user-info small {

    display: block;

    color: #7d8ca0;

    font-size: 10px;

}


.user-info strong {

    color: #172d52;

    font-size: 13px;

}


/* =========================================================
   CONTENT
========================================================= */

.content {

    padding:
        30px 32px;

}


/* =========================================================
   WELCOME CARD
========================================================= */

.welcome-card {

    min-height: 170px;

    border-radius: 18px;

    padding:
        28px 35px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    overflow: hidden;

    position: relative;

    background:
        linear-gradient(
            135deg,
            #ddecfb,
            #c1d8ed
        );

    box-shadow:
        0 10px 30px
        rgba(40,70,110,0.12);

}


/* decorative circle */

.welcome-card::after {

    content: "";

    position: absolute;

    width: 260px;

    height: 260px;

    right: -80px;

    top: -100px;

    border-radius: 50%;

    background:
        rgba(255,255,255,0.25);

}


/* welcome left */

.welcome-left {

    display: flex;

    align-items: center;

    gap: 18px;

    z-index: 2;

}


.welcome-icon {

    width: 65px;

    height: 65px;

    border-radius: 50%;

    background:
        linear-gradient(
            135deg,
            #347bd6,
            #245ba9
        );

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 28px;

    color: white;

    box-shadow:
        0 8px 20px
        rgba(32,88,165,0.25);

}


.welcome-text small {

    color: #405979;

    font-size: 14px;

}


.welcome-text h2 {

    color: #102b57;

    font-size: 27px;

    margin-top: 3px;

}


.welcome-text p {

    color: #607895;

    font-size: 13px;

    margin-top: 8px;

}


.welcome-quote {

    z-index: 2;

    text-align: right;

    max-width: 320px;

    color: #536983;

    font-family: Georgia, serif;

    font-style: italic;

    font-size: 15px;

    line-height: 1.5;

}


.welcome-quote span {

    display: block;

    font-family: Arial;

    font-style: normal;

    font-size: 11px;

    margin-top: 7px;

}


/* =========================================================
   ROOMS SECTION
========================================================= */

.rooms-section {

    background:
        rgba(255,255,255,0.94);

    border-radius: 18px;

    margin-top: 25px;

    padding: 28px;

    box-shadow:
        0 10px 30px
        rgba(40,70,110,0.10);

}


/* =========================================================
   ROOM HEADER
========================================================= */

.rooms-header {

    display: flex;

    align-items: center;

    justify-content: space-between;

    margin-bottom: 24px;

}


.rooms-title {

    display: flex;

    align-items: center;

    gap: 12px;

}


.bed-icon {

    font-size: 29px;

}


.rooms-title h2 {

    font-size: 24px;

    color: #102b57;

}


.rooms-title p {

    color: #728198;

    font-size: 12px;

    margin-top: 4px;

}


.filter-btn {

    border:
        1px solid #dbe3ec;

    background: white;

    padding:
        10px 16px;

    border-radius: 25px;

    cursor: pointer;

    color: #253c60;

    font-weight: bold;

}


/* =========================================================
   ROOMS GRID
========================================================= */

.rooms-container {

    display: grid;

    grid-template-columns:
        repeat(
            auto-fit,
            minmax(180px, 1fr)
        );

    gap: 18px;

}


/* =========================================================
   ROOM CARD
========================================================= */

.room-box {

    min-height: 130px;

    border-radius: 15px;

    padding: 17px;

    display: flex;

    flex-direction: column;

    justify-content: space-between;

    border: 1.5px solid;

    cursor: pointer;

    transition:
        0.25s ease;

}


.room-box:hover {

    transform:
        translateY(-5px);

    box-shadow:
        0 12px 25px
        rgba(30,70,110,0.12);

}


/* available */

.available {

    background:
        linear-gradient(
            135deg,
            #effff5,
            #e1faed
        );

    border-color: #22b88c;

    color: #123d35;

}


/* booked */

.booked {

    background:
        linear-gradient(
            135deg,
            #fff4f5,
            #ffe9eb
        );

    border-color: #ff6d78;

    color: #54232a;

}


/* room top */

.room-top {

    display: flex;

    justify-content: space-between;

    align-items: center;

}


.room-number {

    font-size: 16px;

    font-weight: bold;

}


.room-bed {

    margin-right: 5px;

}


.room-type {

    font-size: 11px;

    color: #65758b;

    margin-top: 6px;

}


.room-arrow {

    font-size: 22px;

    opacity: 0.6;

}


/* status */

.status-badge {

    display: inline-flex;

    align-items: center;

    gap: 6px;

    width: max-content;

    padding:
        6px 11px;

    border-radius: 20px;

    font-size: 10px;

    font-weight: bold;

}


.status-dot {

    width: 7px;

    height: 7px;

    border-radius: 50%;

}


/* available status */

.available .status-badge {

    background: #bdf4dc;

    color: #167657;

}


.available .status-dot {

    background: #13956e;

}


/* booked status */

.booked .status-badge {

    background: #ffc7cc;

    color: #a72538;

}


.booked .status-dot {

    background: #bd2941;

}


/* =========================================================
   ADD ROOM
========================================================= */

.add-room {

    border:
        2px dashed #f0a126;

    background:
        linear-gradient(
            135deg,
            #fffaf0,
            #fff6e4
        );

    color: #dc8508;

    align-items: center;

    justify-content: center;

    text-align: center;

}


.add-icon {

    width: 42px;

    height: 42px;

    border:
        2px solid #e89b25;

    border-radius: 50%;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 25px;

    margin-bottom: 7px;

}


.add-room strong {

    font-size: 13px;

}


.add-room small {

    display: block;

    margin-top: 4px;

    font-size: 10px;

    color: #a87932;

}


/* =========================================================
   MODAL
========================================================= */

.modal-backdrop {

    display: none;

    position: fixed;

    inset: 0;

    background:
        rgba(4,17,34,0.65);

    backdrop-filter:
        blur(5px);

    align-items: center;

    justify-content: center;

    z-index: 5000;

}


.modal-box {

    width: 400px;

    max-width: 90%;

    background: white;

    border-radius: 18px;

    padding: 27px;

    box-shadow:
        0 20px 60px
        rgba(0,0,0,0.25);

    animation:
        modalIn 0.25s ease;

}


@keyframes modalIn {

    from {

        transform:
            translateY(20px);

        opacity: 0;

    }

    to {

        transform:
            translateY(0);

        opacity: 1;

    }

}


.modal-title {

    display: flex;

    align-items: center;

    gap: 12px;

    margin-bottom: 20px;

}


.modal-icon {

    width: 45px;

    height: 45px;

    border-radius: 12px;

    background: #fff0f2;

    display: flex;

    align-items: center;

    justify-content: center;

    font-size: 21px;

}


.modal-title h3 {

    color: #152d54;

    font-size: 18px;

}


.modal-title p {

    color: #8995a6;

    font-size: 11px;

    margin-top: 3px;

}


.detail-row {

    padding:
        12px 0;

    border-bottom:
        1px solid #edf0f4;

}


.detail-label {

    display: block;

    color: #8a95a5;

    font-size: 10px;

    margin-bottom: 4px;

}


.detail-value {

    color: #172e54;

    font-size: 14px;

    font-weight: bold;

}


.modal-actions {

    display: flex;

    justify-content: flex-end;

    gap: 10px;

    margin-top: 23px;

}


.btn-danger {

    background:
        linear-gradient(
            135deg,
            #e84757,
            #c72e40
        );

    color: white;

    border: none;

    padding:
        10px 18px;

    border-radius: 8px;

    cursor: pointer;

    font-weight: bold;

}


.btn-secondary {

    background: #edf1f5;

    color: #41516a;

    border: none;

    padding:
        10px 18px;

    border-radius: 8px;

    cursor: pointer;

    font-weight: bold;

}


/* =========================================================
   RESPONSIVE
========================================================= */

@media(max-width:1000px) {

    .sidebar {

        width: 220px;

    }

    .main {

        margin-left: 220px;

    }

    .welcome-quote {

        display: none;

    }

}


@media(max-width:750px) {

    .sidebar {

        width: 70px;

        padding:
            15px 7px;

    }

    .main {

        margin-left: 70px;

    }

    .logo-text,
    .menu-title,
    .sidebar a span,
    .dropdown-btn span,
    .dropdown-container,
    .arrow {

        display: none;

    }

    .logo-area {

        justify-content: center;

    }

    .sidebar a,
    .dropdown-btn {

        justify-content: center;

        padding:
            13px 5px;

    }

    .last-login {

        display: none;

    }

    .hotel-name h1 {

        font-size: 18px;

        min-width: 200px;

    }

    .content {

        padding:
            20px 15px;

    }

}


@media(max-width:500px) {

    .top-header {

        padding:
            0 15px;

    }

    .hotel-name h1 {

        font-size: 15px;

        min-width: 150px;

    }

    .hotel-name p {

        display: none;

    }

    .crown-image {

        width: 42px;

    }

    .crown-image img {

        width: 38px;

        height: 38px;

    }

    .user-info {

        display: none;

    }

    .welcome-card {

        padding:
            20px;

    }

    .welcome-text h2 {

        font-size: 21px;

    }

    .rooms-section {

        padding:
            18px;

    }

}


/* =========================================================
   TAMIL TYPING CURSOR
========================================================= */

#hotelTyping::after {

    content: "|";

    color: #2872ce;

    margin-left: 3px;

    animation:
        cursorBlink 0.7s infinite;

}


@keyframes cursorBlink {

    0%,
    50% {

        opacity: 1;

    }

    51%,
    100% {

        opacity: 0;

    }

}

</style>


<script>

/* =========================================================
   BOOKING DROPDOWN
========================================================= */

function toggleDrop() {

    let d =
        document.getElementById(
            "bookingDrop"
        );

    if (
        d.style.display === "block"
    ) {

        d.style.display = "none";

    } else {

        d.style.display = "block";

    }

}


/* =========================================================
   REPORT DROPDOWN
========================================================= */

function toggleReports() {

    let d =
        document.getElementById(
            "reportsDrop"
        );

    if (
        d.style.display === "block"
    ) {

        d.style.display = "none";

    } else {

        d.style.display = "block";

    }

}


/* =========================================================
   ROOM FILTER
========================================================= */

function filterRooms(type) {

    document
        .querySelectorAll(
            ".room-box[data-type]"
        )
        .forEach(function(box) {

            let boxType =
                box.dataset.type
                    .toLowerCase()
                    .replace(
                        /[\s-]/g,
                        ""
                    );

            let selectedType =
                type
                    .toLowerCase()
                    .replace(
                        /[\s-]/g,
                        ""
                    );


            if (
                selectedType === "all" ||
                boxType === selectedType
            ) {

                box.style.display =
                    "flex";

            } else {

                box.style.display =
                    "none";

            }

        });

}


/* =========================================================
   OPEN AVAILABLE ROOM
========================================================= */

function openRoom(roomNo) {

    window.location =
        "book_room.php?room=" +
        encodeURIComponent(roomNo);

}


/* =========================================================
   BOOKED ROOM MODAL
========================================================= */

function openRoomModal(
    name,
    mobile,
    idinfo,
    roomNo
) {

    document
        .getElementById("m_name")
        .innerText = name;


    document
        .getElementById("m_mobile")
        .innerText = mobile;


    document
        .getElementById("m_id")
        .innerText = idinfo;


    document
        .getElementById("checkoutBtn")
        .onclick = function() {

            let form =
                document.createElement(
                    "form"
                );


            form.method = "POST";

            form.action =
                "checkout_form.php";


            let input =
                document.createElement(
                    "input"
                );


            input.type = "hidden";

            input.name = "room_no";

            input.value = roomNo;


            form.appendChild(input);

            document.body.appendChild(form);

            form.submit();

        };


    document
        .getElementById("roomModal")
        .style.display = "flex";

}


/* =========================================================
   CLOSE MODAL
========================================================= */

function closeModal() {

    document
        .getElementById("roomModal")
        .style.display = "none";

}


/* =========================================================
   CLOSE MODAL OUTSIDE
========================================================= */

window.addEventListener(
    "click",
    function(event) {

        let modal =
            document.getElementById(
                "roomModal"
            );

        if (
            event.target === modal
        ) {

            closeModal();

        }

    }
);


/* =========================================================
   TAMIL HOTEL TITLE TYPING
========================================================= */

const tamilTexts = [

    "கிராண்ட் பேலஸ் ஹோட்டல்",

    "கிராண்ட் பேலஸ்",

    "உங்கள் வருகை எங்கள் மகிழ்ச்சி",

    "ஆடம்பர அறைகள் & சிறந்த தங்குமிடம்"

];


let textIndex = 0;

let charIndex = 0;

let deleting = false;


/* typing speed */

const typingSpeed = 120;


/* delete speed */

const deletingSpeed = 60;


/* wait after completed text */

const pauseTime = 3000;


function tamilTyping() {

    const element =
        document.getElementById(
            "hotelTyping"
        );


    if (!element) {

        return;

    }


    const currentText =
        tamilTexts[textIndex];


    /* =========================
       TYPING
    ========================= */

    if (!deleting) {

        element.textContent =
            currentText.substring(
                0,
                charIndex + 1
            );


        charIndex++;


        /* completed */

        if (
            charIndex >=
            currentText.length
        ) {

            deleting = true;


            setTimeout(
                tamilTyping,
                pauseTime
            );


            return;

        }


        setTimeout(
            tamilTyping,
            typingSpeed
        );

    }


    /* =========================
       DELETING
    ========================= */

    else {

        element.textContent =
            currentText.substring(
                0,
                charIndex - 1
            );


        charIndex--;


        /* deleted completely */

        if (charIndex <= 0) {

            charIndex = 0;

            deleting = false;

            textIndex++;


            if (
                textIndex >=
                tamilTexts.length
            ) {

                textIndex = 0;

            }


            setTimeout(
                tamilTyping,
                500
            );


            return;

        }


        setTimeout(
            tamilTyping,
            deletingSpeed
        );

    }

}


/* =========================================================
   START TAMIL ANIMATION
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        tamilTyping();

    }
);

</script>

</head>


<body>


<!-- ======================================================
     SIDEBAR
====================================================== -->

<div class="sidebar">


    <div class="logo-area">

        <div class="logo-icon">
            👑
        </div>

        <div class="logo-text">

            <h2>
                Grand Palace
            </h2>

            <p>
                Hotel Management
            </p>

        </div>

    </div>


    <div class="menu-title">
        MAIN MENU
    </div>


    <!-- Dashboard -->

    <a
        class="dashboard-link"
        onclick="filterRooms('all')"
    >

        <span class="menu-icon">
            ⌂
        </span>

        <span>
            Dashboard
        </span>

    </a>


    <!-- Booking -->

    <div
        class="dropdown-btn"
        onclick="toggleDrop()"
    >

        <span class="menu-icon">
            🛏
        </span>

        <span>
            Booking
        </span>

        <span class="arrow">
            ▼
        </span>

    </div>


    <div
        id="bookingDrop"
        class="dropdown-container"
    >

        <a
            onclick="filterRooms('Single')"
        >
            • Single
        </a>

        <a
            onclick="filterRooms('Single(1)')"
        >
            • Single(1)
        </a>

        <a
            onclick="filterRooms('Single-TV')"
        >
            • Single-TV
        </a>

        <a
            onclick="filterRooms('Double')"
        >
            • Double
        </a>

        <a
            onclick="filterRooms('Single-AC')"
        >
            • Single-AC
        </a>

        <a
            onclick="filterRooms('Double-AC')"
        >
            • Double-AC
        </a>

        <a
            onclick="filterRooms('Triple')"
        >
            • Triple
        </a>

        <a
            onclick="filterRooms('Triple-AC')"
        >
            • Triple-AC
        </a>

    </div>


    <div class="sidebar-line"></div>


    <!-- Reports -->

    <div
        class="dropdown-btn"
        onclick="toggleReports()"
    >

        <span class="menu-icon">
            📊
        </span>

        <span>
            Reports
        </span>

        <span class="arrow">
            ▼
        </span>

    </div>


    <div
        id="reportsDrop"
        class="dropdown-container"
    >

        <a href="report_today.php">
            • Today Report
        </a>

        <a href="report_user.php">
            • User Report
        </a>

        <a href="report_overall.php">
            • Overall Report
        </a>

    </div>


    <div class="sidebar-line"></div>


    <!-- Logout -->

    <a
        href="logout.php"
    >

        <span class="menu-icon">
            ↪
        </span>

        <span>
            Logout
        </span>

    </a>


</div>


<!-- ======================================================
     MAIN
====================================================== -->

<div class="main">


    <!-- ==================================================
         HEADER
    ================================================== -->

    <header class="top-header">


        <!-- HOTEL TITLE -->

        <div class="hotel-title">


            <!-- LOCAL CROWN IMAGE -->

            <div class="crown-image">

                <img
                    src="crown.png"
                    alt="Grand Palace Crown"
                >

            </div>


            <!-- TAMIL TYPING -->

            <div class="hotel-name">

                <h1 id="hotelTyping">
                    கிராண்ட் பேலஸ் ஹோட்டல்
                </h1>

                <p>
                    Premium Rooms & Luxury Stay
                </p>

            </div>


        </div>


        <!-- HEADER RIGHT -->

        <div class="header-right">


            <!-- LAST LOGIN -->

            <div class="last-login">

                Last Login

                <strong>
                    <?= htmlspecialchars($lastlog) ?>
                </strong>

            </div>


            <!-- USER -->

            <div class="user-box">


                <div class="user-avatar">
                    👤
                </div>


                <div class="user-info">

                    <small>
                        Welcome,
                    </small>

                    <strong>
                        <?= htmlspecialchars($username) ?>
                        👋
                    </strong>

                </div>


            </div>


        </div>


    </header>



    <!-- ==================================================
         CONTENT
    ================================================== -->

    <main class="content">


        <!-- ==================================================
             WELCOME
        ================================================== -->

        <section class="welcome-card">


            <div class="welcome-left">


                <div class="welcome-icon">
                    🏨
                </div>


                <div class="welcome-text">

                    <small>
                        Welcome Back,
                    </small>


                    <h2>
                        <?= htmlspecialchars($username) ?>
                        👋
                    </h2>


                    <p>
                        Manage rooms, bookings and
                        hotel operations from your
                        dashboard.
                    </p>


                </div>


            </div>


            <div class="welcome-quote">

                “Good rooms.
                Happy stays.”

                <span>
                    — Grand Palace Hotel
                </span>

            </div>


        </section>



        <!-- ==================================================
             ROOMS
        ================================================== -->

        <section class="rooms-section">


            <div class="rooms-header">


                <div class="rooms-title">


                    <div class="bed-icon">
                        🛏
                    </div>


                    <div>

                        <h2>
                            Hotel Rooms
                        </h2>

                        <p>
                            Manage and view all
                            available hotel rooms
                        </p>

                    </div>


                </div>


                <button
                    class="filter-btn"
                    onclick="filterRooms('all')"
                >

                    All Rooms
                    &nbsp;⌄

                </button>


            </div>



            <!-- ==================================================
                 ROOM CARDS
            ================================================== -->

            <div class="rooms-container">


<?php

while (
    $r = mysqli_fetch_assoc($rooms)
) {


    $roomNo =
        (int)$r['room_no'];


    $status =
        strtolower(
            $r['status']
        );


    $originalType =
        $r['room_type'];


    $type =
        strtolower(
            str_replace(
                [' ', '-'],
                '',
                $originalType
            )
        );


    /* ======================================================
       BOOKED ROOM
    ====================================================== */

    if (
        $status === 'booked'
    ) {


        $safeRoom =
            mysqli_real_escape_string(
                $conn,
                $roomNo
            );


        $q = mysqli_query(
            $conn,
            "
            SELECT
                customer_name,
                mobile,
                id_type,
                id_number
            FROM checkins
            WHERE room_no='$safeRoom'
            ORDER BY id DESC
            LIMIT 1
            "
        );


        $c =
            mysqli_fetch_assoc($q);


        $name =
            $c['customer_name']
            ?? 'Unknown';


        $mobile =
            $c['mobile']
            ?? '-';


        $idinfo =
            ($c['id_type']
                ?? '-') .
            ' - ' .
            ($c['id_number']
                ?? '-');


?>


        <div
            class="room-box booked"
            data-type="<?= htmlspecialchars($type) ?>"
            onclick='openRoomModal(
                <?= json_encode($name) ?>,
                <?= json_encode($mobile) ?>,
                <?= json_encode($idinfo) ?>,
                <?= json_encode($roomNo) ?>
            )'
        >


            <div>


                <div class="room-top">


                    <div>


                        <div class="room-number">

                            <span class="room-bed">
                                🛏
                            </span>

                            Room
                            <?= $roomNo ?>

                        </div>


                        <div class="room-type">

                            <?= htmlspecialchars(
                                $originalType
                            ) ?>

                        </div>


                    </div>


                    <div class="room-arrow">
                        ›
                    </div>


                </div>


            </div>


            <div class="status-badge">

                <span class="status-dot"></span>

                Booked

            </div>


        </div>


<?php

    }


    /* ======================================================
       AVAILABLE ROOM
    ====================================================== */

    else {


?>


        <div
            class="room-box available"
            data-type="<?= htmlspecialchars($type) ?>"
            onclick="openRoom(<?= $roomNo ?>)"
        >


            <div>


                <div class="room-top">


                    <div>


                        <div class="room-number">

                            <span class="room-bed">
                                🛏
                            </span>

                            Room
                            <?= $roomNo ?>

                        </div>


                        <div class="room-type">

                            <?= htmlspecialchars(
                                $originalType
                            ) ?>

                        </div>


                    </div>


                    <div class="room-arrow">
                        ›
                    </div>


                </div>


            </div>


            <div class="status-badge">

                <span class="status-dot"></span>

                Available

            </div>


        </div>


<?php

    }

}

?>


                <!-- ==================================================
                     ADD ROOM
                ================================================== -->

                <div
                    class="room-box add-room"
                    onclick="
                        location.href='add_room.php'
                    "
                >

                    <div class="add-icon">
                        +
                    </div>

                    <strong>
                        Add Room
                    </strong>

                    <small>
                        Create new room
                    </small>

                </div>


            </div>


        </section>


    </main>


</div>



<!-- ======================================================
     BOOKED ROOM MODAL
====================================================== -->

<div
    id="roomModal"
    class="modal-backdrop"
>


    <div class="modal-box">


        <div class="modal-title">


            <div class="modal-icon">
                🛏
            </div>


            <div>

                <h3>
                    Booked Room Details
                </h3>

                <p>
                    Current guest information
                </p>

            </div>


        </div>


        <div class="detail-row">

            <span class="detail-label">
                CUSTOMER NAME
            </span>

            <span
                id="m_name"
                class="detail-value"
            ></span>

        </div>


        <div class="detail-row">

            <span class="detail-label">
                MOBILE NUMBER
            </span>

            <span
                id="m_mobile"
                class="detail-value"
            ></span>

        </div>


        <div class="detail-row">

            <span class="detail-label">
                ID PROOF
            </span>

            <span
                id="m_id"
                class="detail-value"
            ></span>

        </div>


        <div class="modal-actions">


            <button
                id="checkoutBtn"
                class="btn-danger"
            >
                Checkout
            </button>


            <button
                onclick="closeModal()"
                class="btn-secondary"
            >
                Close
            </button>


        </div>


    </div>


</div>


</body>

</html>