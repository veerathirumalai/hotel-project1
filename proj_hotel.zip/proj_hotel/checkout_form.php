<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['room_no'])) {
    header("Location: dashboard.php");
    exit();
}

$room_no = (int)$_POST['room_no'];

/* Fetch latest active check-in */
$q = mysqli_query($conn,"
    SELECT c.*, r.price, r.room_type
    FROM checkins c
    JOIN rooms r ON r.room_no = c.room_no
    WHERE c.room_no='$room_no'
    ORDER BY c.id DESC
    LIMIT 1
");

if (!$q || mysqli_num_rows($q) === 0) {
    die("No active check-in found");
}

$c = mysqli_fetch_assoc($q);

$price   = (float)$c['price'];
$advance = (float)$c['advance_amount'];
?>

<!DOCTYPE html>
<html>
<head>
<title>Checkout – Room <?= $room_no ?></title>

<style>
body{font-family:Segoe UI,Arial;background:#f4f6f9}
.box{
    width:900px;margin:30px auto;background:#fff;
    padding:25px;border-radius:8px;
    box-shadow:0 10px 30px rgba(0,0,0,.2)
}
.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:15px}
label{font-weight:600;font-size:13px}
input,textarea{width:100%;padding:8px;border:1px solid #ccc;border-radius:4px}
h3{margin-top:25px;border-bottom:1px solid #ddd;padding-bottom:5px}
button{
    background:#dc3545;color:#fff;padding:12px 30px;
    border:none;border-radius:5px;cursor:pointer
}
.center{text-align:center}
</style>

<script>
function calcBill(){
    let price   = parseFloat(document.getElementById("price").value);
    let advance = parseFloat(document.getElementById("advance").value);

    let cin  = new Date("<?= $c['arrival_date'].' '.$c['arrival_time'] ?>");
    let cout = new Date(
        document.getElementById("checkout_date").value + " " +
        document.getElementById("checkout_time").value
    );

    let days = Math.ceil((cout - cin) / (1000*60*60*24));
    if(days < 1) days = 1;
let discount = parseFloat(document.getElementById("discount").value) || 0;

let base = price * days;
let gst  = base * 0.05;
let grand = base + gst;

let payable = grand - discount - advance;
if (payable < 0) payable = 0;
document.getElementById("days").value = days;
document.getElementById("base").value = base.toFixed(2);
document.getElementById("gst").value  = gst.toFixed(2);
document.getElementById("total").value = grand.toFixed(2);
document.getElementById("payable").value = payable.toFixed(2);
}
window.onload = calcBill;
</script>
</head>

<body>
<div class="box">

<h2>Checkout – Room <?= $room_no ?> (<?= htmlspecialchars($c['room_type']) ?>)</h2>
<p><b>Checked In By:</b> <?= htmlspecialchars($c['checkin_by']) ?></p>

<form method="POST" action="checkout.php">

<input type="hidden" name="room_no" value="<?= $room_no ?>">
<input type="hidden" name="checkin_id" value="<?= $c['id'] ?>">

<h3>Customer</h3>
<div class="grid">
    <div><label>Name</label><input value="<?= $c['customer_name'] ?>" readonly></div>
    <div><label>Mobile</label><input value="<?= $c['mobile'] ?>" readonly></div>
</div>

<h3>Check-in</h3>
<div class="grid">
    <div><label>Date</label><input value="<?= $c['arrival_date'] ?>" readonly></div>
    <div><label>Time</label><input value="<?= $c['arrival_time'] ?>" readonly></div>
</div>

<h3>Checkout</h3>
<div class="grid">
    <div>
        <label>Date</label>
        <input type="date" id="checkout_date" name="checkout_date"
               value="<?= date('d-m-Y ') ?>" onchange="calcBill()" required>
    </div>
    <div>
        <label>Time</label>
        <input type="time" id="checkout_time" name="checkout_time"
               value="<?= date('H:i') ?>" onchange="calcBill()" required>
    </div>
</div>

<h3>Billing</h3>

<label>Price / Day (₹)</label>
<input id="price" value="<?= $price ?>" readonly>

<label>Total Days</label>
<input id="days" name="total_days" readonly>

<label>Base Amount (₹)</label>
<input id="base" name="base_amount" readonly>

<label>GST 5% (₹)</label>
<input id="gst" name="gst_amount" readonly>

<label>Grand Total (₹)</label>
<input id="total" readonly>

<label>Advance Paid (₹)</label>
<input id="advance" value="<?= $advance ?>" readonly>
<label>Discount (₹)</label>
<input type="number" id="discount" name="discount_amount"
       value="0" min="0" oninput="calcBill()">


<label>Payable Amount (₹)</label>
<input id="payable" name="payable_amount" readonly>

<label>Remark</label>
<textarea name="remark"></textarea>

<div class="center">
    <br>
    <button type="submit">Confirm Checkout & Print Bill</button>
</div>

</form>
</div>
</body>
</html>
