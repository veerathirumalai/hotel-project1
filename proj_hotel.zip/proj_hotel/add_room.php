<?php
session_start();
include 'db_connect.php';

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$error = "";
$success = "";

// HANDLE FORM SUBMIT
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $room_no   = trim($_POST['room_no']);
    $floor     = trim($_POST['floor']);
    $room_type = trim($_POST['room_type']);
    $price     = trim($_POST['price']);
    $tv        = trim($_POST['tv']);

    // BASIC VALIDATION
    if ($room_no === "" || $floor === "" || $room_type === "" || $price === "") {
        $error = "All fields are required.";
    } else {

        // CHECK DUPLICATE ROOM
        $check = mysqli_query($conn, "SELECT id FROM rooms WHERE room_no='$room_no'");
        if (mysqli_num_rows($check) > 0) {
            $error = "Room number already exists!";
        } else {

            // INSERT ROOM
            $sql = "INSERT INTO rooms (room_no, floor, room_type, price, tv)
                    VALUES ('$room_no', '$floor', '$room_type', '$price', '$tv')";

            if (mysqli_query($conn, $sql)) {
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Database Error: " . mysqli_error($conn);
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Add New Room</title>
<meta charset="utf-8">

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: linear-gradient(120deg,#1b1f3b,#4a4e69);
}

.form-box {
    width: 480px;
    margin: 70px auto;
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}

h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #1b1f3b;
}

label {
    font-weight: bold;
    margin-top: 10px;
    display: block;
}

input, select {
    width: 100%;
    padding: 11px;
    margin-top: 6px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 15px;
}

input:focus, select:focus {
    outline: none;
    border-color: #1b1f3b;
}

button {
    width: 100%;
    padding: 12px;
    margin-top: 20px;
    background: #1b1f3b;
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #343a70;
}

.error {
    background: #f8d7da;
    color: #842029;
    padding: 10px;
    border-radius: 6px;
    margin-bottom: 15px;
    text-align: center;
}

.back {
    text-align: center;
    margin-top: 15px;
}

.back a {
    color: #1b1f3b;
    text-decoration: none;
    font-weight: bold;
}
</style>
</head>

<body>

<div class="form-box">
<h2>Add New Room</h2>

<?php if ($error !== "") { ?>
    <div class="error"><?php echo $error; ?></div>
<?php } ?>

<form method="post">

    <label>Room Number</label>
    <input type="text" name="room_no" placeholder="Eg: 101" required>

    <label>Floor</label>
    <input type="number" name="floor" placeholder="Eg: 1" required>

    <label>Room Type</label>
    <select name="room_type" required>
        <option value="">-- Select Room Type --</option>
        <option value="Single">Single</option>
        <option value="Single(1)">Single-AC(1)</option>
        <option value="Single-TV">Single-TV</option>
        <option value="Double"> Double</option>
        <option value="Single-AC">Single-AC</option>
        <option value="Double-AC">Douuble-AC</option>
        <option value="Triple">Triple</option>
        <option value="Triple-AC">Triple-AC</option>
        
    </select> 

    <label>Price (₹)</label>
    <input type="number" name="price" placeholder="Eg: 1500" required>

    <label>TV Availability</label>
    <select name="tv">
        <option value="Yes">TV Available</option>
        <option value="No">No TV</option>
    </select>

    <button type="submit">Add Room</button>
</form>

<div class="back">
    <a href="dashboard.php">← Back to Dashboard</a>
</div>
</div>

</body>
</html>
