<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Page</title>
<link rel="stylesheet" href="style.css">
</head>
<?php
session_start();
include("db_connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Fetch user by username ONLY
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {

        $user = mysqli_fetch_assoc($result);

        // VERIFY HASHED PASSWORD
        if (password_verify($password, $user['password'])) {

            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];
            $_SESSION['lastlog']  = date("d-m-Y H:i:s");

            header("Location: dashboard.php");
            exit();

        } else {
            echo "<script>alert('❌ Invalid Password');</script>";
        }

    } else {
        echo "<script>alert('❌ Invalid Username');</script>";
    }
}
?>

<style>body {
  margin: 0;
  font-family: 'Poppins', sans-serif;
  background: url('image/bgima.jpeg') no-repeat center center/cover;
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
}

.login-page {
  display: flex;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border-radius: 20px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  width: 900px;
  height: 450px;
}

/* Left info box */
.login-info {
  flex: 1;
  background: rgba(0, 0, 0, 0.5);
  color: white;
  padding: 40px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

/* Right login form */
.login-container {
  flex: 1;
  padding: 40px;
  text-align: center;
  color: white;
  background: rgba(255, 255, 255, 0.15);
}

.login-container h2 {
  margin-bottom: 20px;
}

.login-container input {
  width: 80%;
  padding: 10px;
  margin: 10px 0;
  border: none;
  border-radius: 10px;
  outline: none;
  font-size: 16px;
}

.login-container button {
  width: 84%;
  padding: 12px;
  border: none;
  border-radius: 10px;
  background: gold;
  color: black;
  font-weight: bold;
  font-size: 16px;
  cursor: pointer;
  transition: 0.3s;
}

.login-container button:hover {
  background: orange;
}
</style>
<body>

<div class="login-page">

  <!-- Left Side Info Box -->
  <div class="login-info">
    <h2>N.M.S.S.MUTHUCHAMY NADAR MANSION</h2>
    <p>
      Please login using your registered username and password.<br><br>
      <strong>Login Rules:</strong><br>
      1Enter valid credentials only.<br>
      2Do not share your password with others.<br>
      3Make sure Caps Lock is turned off.<br>
      4 Contact admin for any login issues.<br><br>
      Have a great day managing your bookings! 
    </p>
  </div>

  <!-- Right Side Login Form -->
  <div class="login-container">
   <form method="post">
    Username:<br>
    <input type="text" name="username" required><br><br>

    Password:<br>
    <input type="password" name="password" required><br><br>

    <button type="submit">Login</button>
</form>

  </div>

</div>
<hr>
<p style="text-align:center;">
    New Staff?
    <a href="sign_up.php"><b>Sign Up</b></a>
</p>


</body>
</html>
