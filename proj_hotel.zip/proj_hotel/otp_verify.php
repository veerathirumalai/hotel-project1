<?php
session_start();
include("db_connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $_SESSION['username'] = $_POST['username'];
    $_SESSION['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $_SESSION['mobile']   = $_POST['mobile'];

    // Check unique username
    $u = $_POST['username'];
    $check = mysqli_query($conn, "SELECT id FROM users WHERE username='$u'");
    if(mysqli_num_rows($check) > 0){
        die("❌ Username already exists. Go back and choose another.");
    }

    $_SESSION['otp'] = rand(100000,999999);
}
?>

<!DOCTYPE html>
<html>
<head><title>OTP Verification</title></head>
<body style="font-family:Arial;text-align:center;margin-top:80px;">

<h2>OTP Verification</h2>

<p><b>Your OTP:</b> <?php echo $_SESSION['otp']; ?></p>
<!-- OTP shown only for testing -->

<form method="post" action="signup_success.php">
    Enter OTP:<br><br>
    <input type="text" name="otp" required>
    <br><br>
    <button>Verify OTP</button>
</form>

</body>
</html>
